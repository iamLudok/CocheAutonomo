#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <string.h>
#include "pigpio.h"


#include "burualdea.h"
#include "ldr_burualdea.h"
#include "dijkstra.h"
#include "BLE_burualdea.h"


int main(int argc, char* argv[])
{
	int status;
	int mugimenduak[MAX];
	REMOTE_ORDER r_order;
	char karak;
	int aukera;
	int modua;
	int dijkstraf;
	status=gpioInitialise();

	if(status<0) return -1;

	printf("---------------Program is starting... ------------------\n");

	init_hw();

	printf("Eskuz edo Basys-arekin zaude? (1 esku, 2 Basys)\n");
	scanf("%d", &aukera);

	switch(aukera){
	case(1):
		printf("1 (automatikoa) 2 (bide laburra) 3 (teklatuz)\n");
		scanf("%d", &modua);

		if(modua==1)
		{
			while(1){
				dijkstraf = 0;
				kalibratu(dijkstraf);
			}
		}
		else if(modua==2)
		{
			dijkstraf = 1;
			dijkstra(mugimenduak, dijkstraf);
		}
		else
		{
			teklatuarekinIbili();
		}
		break;
	case(2):
			if (argc == 1) {
				printf("Usage: %s [device]\n\n", argv[0]);
				return -1;
			}

			printf("Opening %s\n", argv[1]);
			status = init_ble(argv[1]);
			printf("%d\n", status);
			if (status <= 0 ) printf("[ERROR]Opening dev=%s\n", argv[1]);

			while(1)
			{
				karak=modua_aukeratu();
				while (karak=='w'||karak=='a'||karak=='s'||karak=='d'||karak=='r')
				{
					r_order = read_remote_order();
					BLE_mugitu(r_order);
					karak=modua_aukeratu();
				}

				while (karak=='n')
				{
					dijkstraf = 0;
					kalibratu(dijkstraf);
					karak=modua_aukeratu();
				}

				while (karak=='o')
				{
					dijkstra(mugimenduak, dijkstraf);
					karak=modua_aukeratu();
				}
			}
			close(argv[1]);
			break;
	}

	return 0;
}

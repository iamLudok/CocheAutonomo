#ifndef DIJKSTRA_H
#define DIJKSTRA_H

#define INFINITO 9999999
#define MAX 16

typedef struct nodoak {

	char id;
	char nondik;
	char nora;
	int orientazioa;
	int dist;

}NODO_BAKOITZA;

typedef struct nodo {

	NODO_BAKOITZA nodo[MAX];

}NODOAK;

typedef struct ibilbidea {
	int nondik;	//Indica desde donde llegamos a un cierto vertice
	int dist;	//Indica la distancia desde el origen
} IBILBIDEA;

typedef struct bidea {
	char id;
}BIDEA;



NODOAK* datuak_fitxategitik_jaso(int kop);
void matrizea_sortu(int kop, NODOAK* infor, int M[MAX][MAX]);
BIDEA* dijkstraAlgoritmoa(int M[MAX][MAX], int hasieraPuntua, int helmuga, int kop);
int direkzioakGorde(int mugimenduak[MAX], NODOAK* informazioa, BIDEA* saltoak, int helmuga);
void dijkstra(int mugimenduak[MAX], int dijkstraf);
void birakBistaratu(int mugimenduak[MAX], int kop, int nodoKop, int dijkstraf);
char direkzioa(int nora, int nondik);

#endif

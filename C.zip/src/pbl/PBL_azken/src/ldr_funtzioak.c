#include <stdio.h>
#include "pigpio.h"

#include "ldr_burualdea.h"
#include "burualdea.h"


int nodoaAurkitu()
{
	int value=1;
	unsigned int time=0;
	unsigned int start_time;
	int sensor_value=1;
	int status = 0;
	int nodo=0;
	int pinak[8]={9, 10, 19, 12, 16, 20, 13, 11};
	int nodoan[2];
	int i;
	status = gpioInitialise();

	if (status > 0)
	{
		for(i=0;i<8;i++)
		{
			value=1;
			gpioSetMode(pinak[i], PI_OUTPUT);
			gpioWrite(pinak[i], 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(pinak[i], PI_INPUT);
			start_time = gpioTick();
			time = gpioTick()-start_time;

			while ( time < READING_TIMEOUT && value != 0 ){
				time = gpioTick()-start_time;
				value =  gpioRead(pinak[i]);
				if( value == 0){
					sensor_value = time;
				}
			}
			if(i==0)
			{
				nodoan[0]=sensor_value;
			}
			else if (i==7)
			{
				nodoan[1]=sensor_value;
			}
		}
			if(nodoan[0]>BELTZ_MIN && nodoan[1]>BELTZ_MIN)
			{
				nodo=1;
			}
		}
	return nodo;
}

void kalibratu(int dijkstra)
{
	int value=1, value2=1, value3=1, value4=1, value5=1, value6=1, value7=1, value8=1;
	unsigned int time=0, time2=0, time3=0, time4=0, time5=0, time6=0, time7=0, time8=0;
	unsigned int start_time, start_time2, start_time3, start_time4, start_time5, start_time6, start_time7, start_time8;
	int sensor_value=1, sensor_value2=1, sensor_value3=1, sensor_value4=1, sensor_value5=1, sensor_value6=1, sensor_value7, sensor_value8;
	int status = 0;
	status = gpioInitialise();

	if (status > 0)
	{
			//5. sentsorea
			gpioSetMode(16, PI_OUTPUT);
			gpioWrite(16, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(16, PI_INPUT);
			start_time5 = gpioTick();
			time5 = gpioTick()-start_time5;

			while ( time5 < READING_TIMEOUT && value5 != 0 ){
				time5 = gpioTick()-start_time5;
				value5 =  gpioRead(16);
				if( value5 == 0){
					sensor_value5 = time5;
				}
			}
			//4. sentsorea
			gpioSetMode(12, PI_OUTPUT);
			gpioWrite(12, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(12, PI_INPUT);
			start_time4 = gpioTick();
			time4 = gpioTick()-start_time4;

			while ( time4 < READING_TIMEOUT && value4 != 0 ){
				time4 = gpioTick()-start_time4;
				value4 =  gpioRead(12);
				if( value4 == 0){
					sensor_value4 = time4;
				}
			}

			//6. sentsorea
			gpioSetMode(20, PI_OUTPUT);
			gpioWrite(20, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(20, PI_INPUT);
			start_time6 = gpioTick();
			time6 = gpioTick()-start_time6;

			while ( time6 < READING_TIMEOUT && value6 != 0 ){
				time6 = gpioTick()-start_time6;
				value6 =  gpioRead(20);
				if( value6 == 0){
					sensor_value6 = time6;
				}
			}

			//3. sentsorea
			gpioSetMode(19, PI_OUTPUT);
			gpioWrite(19, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(19, PI_INPUT);
			start_time3 = gpioTick();
			time3 = gpioTick()-start_time3;

			while ( time3 < READING_TIMEOUT && value3 != 0 ){
				time3 = gpioTick()-start_time3;
				value3 =  gpioRead(19);
				if( value3 == 0){
					sensor_value3 = time3;
				}
			}

			//7. sentsorea
			gpioSetMode(13, PI_OUTPUT);
			gpioWrite(13, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(13, PI_INPUT);
			start_time7 = gpioTick();
			time7 = gpioTick()-start_time7;

			while ( time7 < READING_TIMEOUT && value7 != 0 ){
				time7 = gpioTick()-start_time7;
				value7 =  gpioRead(13);
				if( value7 == 0){
					sensor_value7 = time7;
				}
			}

			//2. sentsorea
			gpioSetMode(10, PI_OUTPUT);
			gpioWrite(10, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(10, PI_INPUT);
			start_time2 = gpioTick();
			time2 = gpioTick()-start_time2;

			while ( time2 < READING_TIMEOUT && value2!= 0 ){
				time2 = gpioTick()-start_time2;
				value2 =  gpioRead(10);
				if( value2 == 0){
					sensor_value2 = time2;
				}
			}

			//8. sentsorea
			gpioSetMode(11, PI_OUTPUT);
			gpioWrite(11, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(11, PI_INPUT);
			start_time8 = gpioTick();
			time8 = gpioTick()-start_time8;

			while ( time8 < READING_TIMEOUT && value8 != 0 ){
				time8 = gpioTick()-start_time8;
				value8 =  gpioRead(11);
				if( value8 == 0){
					sensor_value8 = time8;
				}
			}

			//1. sentsorea
			gpioSetMode(18, PI_OUTPUT);
			gpioWrite(9, 1);
			gpioDelay(CHARGE_TIME);
			gpioSetMode(9, PI_INPUT);
			start_time = gpioTick();
			time = gpioTick()-start_time;

			while ( time < READING_TIMEOUT && value != 0 ){
				time = gpioTick()-start_time;
				value =  gpioRead(9);
				if( value == 0){
					sensor_value = time;
				}
			}
			printf("8: %d 7: %d 6: %d 5: %d 4: %d 3: %d 2: %d 1: %d\n", sensor_value8, sensor_value7, sensor_value6, sensor_value5, sensor_value4, sensor_value3, sensor_value2, sensor_value);

			mugitu_marra(sensor_value, sensor_value2, sensor_value3, sensor_value4, sensor_value5, sensor_value6, sensor_value7, sensor_value8, dijkstra);

			value=1;
			value2=1;
			value3=1;
			value4=1;
			value5=1;
			value6=1;
			value7=1;
			value8=1;
	}
}

void mugitu_marra(int sensor_value, int sensor_value2, int sensor_value3, int sensor_value4, int sensor_value5, int sensor_value6, int sensor_value7, int sensor_value8, int dijkstra)
{
	if ((dijkstra == 0) && sensor_value8 > BELTZ_MIN && sensor_value7 > BELTZ_MIN && sensor_value6 > BELTZ_MIN && sensor_value5 > BELTZ_MIN && sensor_value4 > BELTZ_MIN && sensor_value3 > BELTZ_MIN && sensor_value2 > BELTZ_MIN && sensor_value > BELTZ_MIN)
	{
		accionarMotor(STOP);
	}
	else if (sensor_value5 > BELTZ_MIN && sensor_value4 > BELTZ_MIN && sensor_value3 < ZURI_MAX && sensor_value6 < ZURI_MAX)
	{
		accionarMotor(STRAIGHT);
	}
	else if (sensor_value3 > BELTZ_MIN && sensor_value5 < ZURI_MAX)
	{
		accionarMotor(LEFT);
	}
	else if (sensor_value6 > BELTZ_MIN && sensor_value4 < ZURI_MAX)
	{
		accionarMotor(RIGHT);
	}
	/*else if (sensor_value > BELTZ_MIN && sensor_value2 > BELTZ_MIN) // 90º-ko kurbak hartu behar ezean, bi if hauek ez dira beharrezkoak.
	{
		accionarMotor(LEFT);
		wait_seg(1);
		gpioDelay(3000000);
		accionarMotor(STOP);
		while(i<1150000)
		{
			accionarMotor(LEFT);
			i++;
		}
	}*/
	/*else if (sensor_value7 > BELTZ_MIN && sensor_value8 > BELTZ_MIN)
	{
		accionarMotor(RIGHT);
		wait_seg(1);
		gpioDelay(3000000);
		accionarMotor(STOP);
		while(i<1150000)
		{
			accionarMotor(RIGHT);
			i++;
		}
	}*/
}



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <termios.h>

#include "pigpio.h"
#include "burualdea.h"

void init_hw(void){
	gpioSetMode(MOTOR_1_PIN, PI_OUTPUT);
	gpioSetMode(MOTOR_2_PIN, PI_OUTPUT);
	gpioSetMode(MOTOR_3_PIN, PI_OUTPUT);
	gpioSetMode(MOTOR_4_PIN, PI_OUTPUT);

	gpioSetMode(MOTOR_1_A_PIN, PI_OUTPUT);
	gpioSetMode(MOTOR_2_A_PIN, PI_OUTPUT);
	gpioSetMode(MOTOR_3_A_PIN, PI_OUTPUT);
	gpioSetMode(MOTOR_4_A_PIN, PI_OUTPUT);
}

int tekla_return_gabe()
{
    struct timeval tv;
    fd_set fds;
    tv.tv_sec = 0;
    tv.tv_usec = 0;
    FD_ZERO(&fds);
    FD_SET(STDIN_FILENO, &fds); //STDIN_FILENO is 0
    select(STDIN_FILENO+1, &fds, NULL, NULL, &tv);
    return FD_ISSET(STDIN_FILENO, &fds);
}

void nonblock(int state)
{
    struct termios ttystate;

    //get the terminal state
    tcgetattr(STDIN_FILENO, &ttystate);

    if (state==NB_ENABLE)
    {
        //turn off canonical mode
        ttystate.c_lflag &= ~ICANON;
        //minimum of number input read.
        ttystate.c_cc[VMIN] = 1;
    }
    else if (state==NB_DISABLE)
    {
        //turn on canonical mode
        ttystate.c_lflag |= ICANON;
    }
    //set the terminal attributes.
    tcsetattr(STDIN_FILENO, TCSANOW, &ttystate);
}

void accionarMotor(ORDEN orden){
	switch(orden){
		case RIGHT:
			gpioPWM(MOTOR_1_PIN, 200);
			gpioPWM(MOTOR_2_PIN, 0);
			gpioPWM(MOTOR_3_PIN, 0);
			gpioPWM(MOTOR_4_PIN, 200);

			gpioWrite(MOTOR_2_A_PIN, TRUE);
			gpioWrite(MOTOR_3_A_PIN, TRUE);
			gpioWrite(MOTOR_4_A_PIN, FALSE);
			gpioWrite(MOTOR_1_A_PIN, FALSE);
			break;
		case LEFT:
			gpioPWM(MOTOR_1_PIN, 0);
			gpioPWM(MOTOR_2_PIN, 200);
			gpioPWM(MOTOR_3_PIN, 200);
			gpioPWM(MOTOR_4_PIN, 0);

			gpioWrite(MOTOR_2_A_PIN, FALSE);
			gpioWrite(MOTOR_3_A_PIN, FALSE);
			gpioWrite(MOTOR_4_A_PIN, TRUE);
			gpioWrite(MOTOR_1_A_PIN, TRUE);
			break;
		case STRAIGHT:
			gpioPWM(MOTOR_1_PIN, 150);
			gpioPWM(MOTOR_2_PIN, 150);
			gpioPWM(MOTOR_3_PIN, 150);
			gpioPWM(MOTOR_4_PIN, 150);

			gpioWrite(MOTOR_2_A_PIN, FALSE);
			gpioWrite(MOTOR_3_A_PIN, FALSE);
			gpioWrite(MOTOR_4_A_PIN, FALSE);
			gpioWrite(MOTOR_1_A_PIN, FALSE);
			break;
		case STOP:
			gpioWrite(MOTOR_1_PIN, FALSE);
			gpioWrite(MOTOR_2_PIN, FALSE);
			gpioWrite(MOTOR_3_PIN, FALSE);
			gpioWrite(MOTOR_4_PIN, FALSE);

			gpioWrite(MOTOR_2_A_PIN, FALSE);
			gpioWrite(MOTOR_3_A_PIN, FALSE);
			gpioWrite(MOTOR_4_A_PIN, FALSE);
			gpioWrite(MOTOR_1_A_PIN, FALSE);
			break;
		case REVERSE:
			gpioPWM(MOTOR_1_A_PIN, 150);
			gpioPWM(MOTOR_2_A_PIN, 150);
			gpioPWM(MOTOR_3_A_PIN, 150);
			gpioPWM(MOTOR_4_A_PIN, 150);

			gpioWrite(MOTOR_1_PIN, FALSE);
			gpioWrite(MOTOR_2_PIN, FALSE);
			gpioWrite(MOTOR_3_PIN, FALSE);
			gpioWrite(MOTOR_4_PIN, FALSE);
			break;
		default:
			break;
	}
}

void teklatuarekinIbili(void)
{
	int pressed=0;
	char c;
	nonblock(NB_ENABLE);
	printf("Erabili w-a-s-d-r\n");
	do{
		usleep(1);

		pressed=tekla_return_gabe();
		if (pressed!=0)
		{
			c=fgetc(stdin);
		}

		switch(c){
		case 'a':
			accionarMotor(LEFT);
			break;
		case 'd':
			accionarMotor(RIGHT);
			break;
		case 'w':
			accionarMotor(STRAIGHT);
			break;
		case 's':
			accionarMotor(STOP);
			break;
		case 'r':
			accionarMotor(REVERSE);
			break;
		default:
			break;
	}

	} while(c!='q');

	accionarMotor(STOP);
    nonblock(NB_DISABLE);
}

#ifndef BURUALDEA_H_
#define BURUALDEA_H_

#define TRUE 1
#define FALSE 0
#define NB_ENABLE 1
#define NB_DISABLE 0

#define MOTOR_1_PIN  23
#define MOTOR_1_A_PIN  21
#define MOTOR_2_PIN  5
#define MOTOR_2_A_PIN  26
#define MOTOR_3_PIN  8
#define MOTOR_3_A_PIN  2
#define MOTOR_4_PIN  25
#define MOTOR_4_A_PIN  3

typedef enum {RIGHT, LEFT, STRAIGHT,STOP, REVERSE}ORDEN;

int tekla_return_gabe();
void nonblock(int state);
void init_hw(void);
void accionarMotor(ORDEN orden);
void teklatuarekinIbili();

#endif

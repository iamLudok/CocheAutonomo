#include <stdio.h>

#include "pigpio.h"

#include <stdlib.h>
#include <unistd.h>
#include <sys/select.h>
#include <termios.h>
#include <stdio.h>
#include <fcntl.h>

#include "BLE_burualdea.h"
#include "burualdea.h"

int fd=0;

int init_ble(char* dev){
	struct termios serial;

	printf("Opening %s\n", dev);

	fd = open(dev, O_RDWR | O_NOCTTY | O_NDELAY);

	if (fd == -1) {
		perror(dev);
		return -1;
	}

	if (tcgetattr(fd, &serial) < 0) {
		perror("Getting configuration");
		return -1;
	}

	// Set up Serial Configuration
	serial.c_iflag = 0;
	serial.c_oflag = 0;
	serial.c_lflag = 0;
	serial.c_cflag = 0;

	serial.c_cc[VMIN] = 0;
	serial.c_cc[VTIME] = 0;

	serial.c_cflag = B115200 | CS8 | CREAD;

	tcsetattr(fd, TCSANOW, &serial); // Apply configuration
	return fd;
}

REMOTE_ORDER read_remote_order(){

	REMOTE_ORDER  order;
	char buffer[10];
	order=R_STOP;

	int rcount = 0;
	*buffer = 0;
	do{
		rcount  = read(fd, buffer, sizeof(buffer));
		if (rcount < 0) {
			perror("Read");
			return -1;
		}
		else {
			if (rcount > 0) {
				printf("==============================REMOTE ORDER================================\n");
				printf("RECEIVED %c\n",*buffer);
			}
		}
	}while( *buffer == 0 || rcount == 0 );

	printf("Buffer: %s\n", buffer);

	switch (*buffer){
		case R_MODE:
			order = R_MODE;
			printf("MODE %c\n",*buffer);
			break;
		case R_FORWARD:
			order = R_FORWARD;
			 printf("FORWARD %c\n",*buffer);
			 break;
		case R_BACKWARD:
			printf("BACKWARD %c\n",*buffer);
			order = R_BACKWARD;
			break;
		case R_RIGHT:
			printf("RIGHT %c\n",*buffer);
			order = R_RIGHT;
			break;
		case R_LEFT:
			printf("LEFT %c\n",*buffer);
			order = R_LEFT;
			break;
		case R_STOP:
			printf("STOP %c\n",*buffer);
			order = R_STOP;
			break;
		default:
			printf("NO ORDER  %c\n",*buffer);
			order = R_NONE;
	}

	buffer[rcount] = '\0';
	if (order != R_NONE ) printf("Jasotakoa: ORDEN %s\n", buffer);

	return order;
}

char modua_aukeratu()
{
	char buffer[10];
	char karak;
	int rcount = 0;

	*buffer = 0;
	do{
		rcount  = read(fd, buffer, sizeof(buffer));
		if (rcount < 0) {
			perror("Read");
			return -1;
		}
	}while( *buffer == 0 || rcount == 0 );

	karak=buffer[0];

	return karak;
}

void BLE_mugitu(REMOTE_ORDER r_order)
{
	switch (r_order){
		case R_FORWARD:
			accionarMotor(STRAIGHT);
		break;
		case R_BACKWARD:
			accionarMotor(REVERSE);
		break;
		case R_RIGHT:
			accionarMotor(RIGHT);
		break;
		case R_LEFT:
			accionarMotor(LEFT);
		break;
		case R_STOP:
			accionarMotor(STOP);
		break;
		default:
			accionarMotor(STOP);
			break;
	}
}

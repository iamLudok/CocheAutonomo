#ifndef BLE_BURUALDEA_H_
#define BLE_BURUALDEA_H_

typedef enum Remote_order{R_MODE='c', R_FORWARD='w', R_BACKWARD='r', R_RIGHT='d', R_LEFT='a' , R_STOP='s' , R_NONE} REMOTE_ORDER;

int init_ble(char* dev);
REMOTE_ORDER read_remote_order();
char modua_aukeratu();
void BLE_mugitu(REMOTE_ORDER r_order);

#endif

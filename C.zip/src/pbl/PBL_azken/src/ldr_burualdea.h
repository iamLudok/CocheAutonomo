#ifndef LDR_BURUALDEA_H_
#define LDR_BURUALDEA_H_

#define READING_TIMEOUT 1000
#define CHARGE_TIME 10
#define BELTZ_MIN 210
#define ZURI_MAX 200
#define MAX_PIN 8

void mugitu_marra(int sensor_value, int sensor_value2, int sensor_value3, int sensor_value4, int sensor_value5, int sensor_value6, int sensor_value7, int sensor_value8, int dijkstra);
void kalibratu(int dijkstra);
int nodoaAurkitu();

#endif

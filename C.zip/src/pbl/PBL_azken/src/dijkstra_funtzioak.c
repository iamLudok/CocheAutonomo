#include <stdio.h>


#include "pigpio.h"

#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/select.h>
#include <termios.h>
#include <stdio.h>
#include <fcntl.h>

#include "dijkstra.h"
#include "burualdea.h"

void dijkstra(int mugimenduak[MAX], int dijkstraf) {

	NODOAK* informazioa = (NODOAK*)malloc(20 * sizeof(NODOAK));
	BIDEA* motzena;
	int kop = MAX, hasiera, bukaera;
	int nodoKop;
	char str[128];
	char c;
	int pM[MAX][MAX];

	informazioa = datuak_fitxategitik_jaso(kop);

	matrizea_sortu(kop, informazioa, pM);

	printf("\n\n\n\n===========================Sartu A-tik %c-rainoko bide bat (handiz)=======================================\n", kop+'A');

	fgets(str, 128, stdin);
	printf("Sartu hasierako puntua: ");
	fgets(str, 128, stdin);
	sscanf(str, "%c", &c);
	hasiera = c - 'A';

	printf("Sartu bukaerako puntua: ");
	fgets(str, 128, stdin);
	sscanf(str, "%c", &c);
	bukaera = c - 'A';

	motzena = dijkstraAlgoritmoa(pM, hasiera, bukaera, kop);

	nodoKop = direkzioakGorde(mugimenduak, informazioa, motzena, bukaera);

	birakBistaratu(mugimenduak, kop, nodoKop, dijkstraf);

}

NODOAK* datuak_fitxategitik_jaso(int kop) {

	FILE* fitx = fopen("./datuak.txt", "r");
	NODOAK tmp;
	NODOAK* informazioa = (NODOAK*)malloc(20 * sizeof(NODOAK));
	NODOAK aux;

	int i = 0;
	int egoera;
	int  z;
	int j = 0;

	if (fitx > 0) {
		egoera = fscanf(fitx, "id: %c\n", &tmp.nodo[i].id);

		if (egoera == 1) {

			do {

				do {

					egoera = fscanf(fitx, "hasiera: %c, amaiera: %c, orientazioa: %d, pisua: %d\n", &tmp.nodo[i].nondik, &tmp.nodo[i].nora, &tmp.nodo[i].orientazioa, &tmp.nodo[i].dist);
					if (egoera == 4) {

						tmp.nodo[i].id = tmp.nodo[i].nondik;
						i++;
					}


				} while (egoera == 4);

				for (z = 0; z < i; z++) {
					informazioa[j].nodo[z] = tmp.nodo[z];

				}

				j++;
				i = 0;
				egoera = fscanf(fitx, "id: %c\n", &aux.nodo[i].id);

			} while (j < kop && egoera > 0);

			printf("Dokumentuko datu guztiak ondo kargatu dira.\n");

		}
		else printf("ERROR: Ez dago nodorik.\n");

	}
	else {
		printf("ERROR ezin izan dira dokumentuko datuak kopiatu.\n");
	}
	fclose(fitx);


	return informazioa;
}


void matrizea_sortu(int kop, NODOAK* infor, int M[MAX][MAX]) {

	int i, j = 0;
	int kond = 0;
	int kond2;

	for (i = 0; i < kop; i++) {
		for (j = 0; j < kop; j++) {
			M[i][j] = -1;
		}
	}

	for (i = 0; i < kop; i++) {
		kond2 = infor[i].nodo[0].id;
		kond = kond2 - 'A';
		M[i][kond] = 0;
	}

	for (i = 0; i < kop; i++) {
		j = 0;
		do
		{
			kond2 = infor[i].nodo[j].nora;
			kond = kond2 - 'A';
			M[i][kond] = infor[i].nodo[j].dist;
			j++;
		} while (infor[i].nodo[j].id == infor[i].nodo[j - 1].id);
	}
}

BIDEA* dijkstraAlgoritmoa(int pM[MAX][MAX], int hasieraPuntua, int helmuga, int kop) {

	int ikusita[144];
	IBILBIDEA* bidea2 = (IBILBIDEA*)malloc(MAX * sizeof(IBILBIDEA));
	BIDEA* ret = (BIDEA*)malloc(MAX * sizeof(BIDEA));
	BIDEA* aux = (BIDEA*)malloc(MAX * sizeof(BIDEA));


	int kont = 0, distMin, hurrengoNodoa, i, j, c;
	int M[MAX][MAX];

	for (i = 0; i < kop; i++) {

		for (j = 0; j < kop; j++) {
			if (pM[i][j] == -1) {
				M[i][j] = INFINITO;

			}
			else {
				M[i][j] = pM[i][j];

			}
		}
	}

	for (i = 0; i < kop; i++) {
		bidea2[i].dist = M[hasieraPuntua][i];
		bidea2[i].nondik = hasieraPuntua;
		ikusita[i] = 0;
	}

	bidea2[hasieraPuntua].dist = 0;
	ikusita[hasieraPuntua] = 1;
	kont = 1;

	while (kont < kop - 1) {

		distMin = INFINITO;

		for (i = 0; i < kop; i++) {

			if (bidea2[i].dist < distMin && ikusita[i] == 0) {

				distMin = bidea2[i].dist;

				hurrengoNodoa = i;
			}
		}
		ikusita[hurrengoNodoa] = 1;

		for (i = 0; i < kop; i++) {

			if (ikusita[i] == 0) {
				if (distMin + M[hurrengoNodoa][i] < bidea2[i].dist) {
					bidea2[i].dist = distMin + M[hurrengoNodoa][i];
					bidea2[i].nondik = hurrengoNodoa;
				}
			}
		}
		kont++;
	}

	c = 'A' + helmuga;

	printf("\nDistantzia nodora %c = %d", c, bidea2[helmuga].dist);

	printf("\nBidea= %c", c);

	j = helmuga;
	i = 0;
	ret[i].id = c;

	do {
		j = bidea2[j].nondik;
		i++;

		c = 'A' + j;
		printf("<-%c", c);
		ret[i].id = c;
	} while (j != hasieraPuntua);

	for (j = 0; j <= i; j++) {
		aux[j].id = ret[i - j].id;
	}

	return aux;
}

int direkzioakGorde(int mugimenduak[MAX], NODOAK* informazioa, BIDEA* saltoak, int helmuga) {

	int i = 0, j = 0, z = 0;
	int kond = helmuga + 'A';


	do {
		j = 0;
		z = 0;
		while (saltoak[i].id != informazioa[j].nodo[0].id) {
			j++;
		}

		while (saltoak[i + 1].id != informazioa[j].nodo[z].nora)
		{
			z++;
		}
		mugimenduak[i] = informazioa[j].nodo[z].orientazioa;
		i++;

	} while (saltoak[i].id != kond);
	return i;
}


void birakBistaratu(int mugimenduak[MAX], int kop, int nodoKop, int dijkstraf) {

	int nondik, nora, i = 0, bukatu=0;
	char norabide='a';

	printf("\nHASIERA:   Zuzen->");

	while (i < nodoKop) {

		if(i == (nodoKop - 1))
		{
			bukatu=1;
		}
		while((nodoaAurkitu())!=1)
		{
			kalibratu(dijkstraf);
		}
		if(bukatu==0)
		{
			gpioDelay(400000);
		}
		accionarMotor(STOP);

		nondik = mugimenduak[i];
		nora = mugimenduak[i+1];

		norabide = direkzioa(nora, nondik);

		if(norabide=='r')
		{
			accionarMotor(RIGHT);
			gpioDelay(1400000);
			accionarMotor(STOP);
		}
		else if (norabide=='l')
		{
			accionarMotor(LEFT);
			gpioDelay(1000000);
			accionarMotor(STOP);
		}

		i++;
	}
	accionarMotor(STOP);
	printf("HELMUGA");
}

char direkzioa(int nora, int nondik) {

	char karak='a';
	if (nondik == 0) {
		if (nora == 3) {
			printf("Eskuinera->");
			karak='r';
		}
		else if (nora == 1) {
			printf("Ezkerrera->");
			karak='l';
		}
		else if (nora == 0) {
			printf("Zuzen->");
			karak='a';
		}
	}
	else if (nondik == 1) {
		if (nora == 0) {
			printf("Eskuinera->");
			karak='r';
		}
		else if (nora == 2) {
			printf("Ezkerrera->");
			karak='l';
		}
		else if (nora == 1) {
			printf("Zuzen->");
			karak='a';
		}
	}
	else if (nondik == 2) {

		if (nora == 1) {
			printf("Eskuinera->");
			karak='r';
		}
		else if (nora == 3) {
			printf("Ezkerrera->");
			karak='l';
		}
		else if (nora == 2) {
			printf("Zuzen->");
			karak='a';
		}
	}
	else if (nondik == 3) {
		if (nora == 2) {
			printf("Eskuinera->");
			karak='r';
		}
		else if (nora == 0) {
			printf("Ezkerrera->");
			karak='l';
		}
		else if (nora == 3) {
			printf("Zuzen->");
			karak='a';
		}
	}
	return karak;
}
